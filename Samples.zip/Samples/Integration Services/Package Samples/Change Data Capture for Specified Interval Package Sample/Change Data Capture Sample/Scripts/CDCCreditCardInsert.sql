/*=====================================================================
  This file is part of a Microsoft SQL Server Shared Source Application.
  Copyright (C) Microsoft Corporation.  All rights reserved.
 
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
======================================================= */
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 8000 and CreditCardID  <= 12000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 12000 and CreditCardID  <= 13000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 13000 and CreditCardID  <= 14000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 14000 and CreditCardID  <= 15000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 15000 and CreditCardID  <= 16000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 16000 and CreditCardID  <= 17000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 17000 and CreditCardID  <= 18000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 18000 and CreditCardID  <= 19000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 19000 and CreditCardID  <= 20000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 20000 and CreditCardID  <= 21000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 21000 and CreditCardID  <= 22000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 22000 and CreditCardID  <= 23000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 23000 and CreditCardID  <= 25000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 25000 and CreditCardID  <= 27000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 27000 and CreditCardID  <= 29000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.CreditCard
select CreditCardID, CardType, CardNumber, ExpMonth, ExpYear, getdate()
from Sales.CreditCard
where CreditCardID > 29000 and CreditCardID  <= 32000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go

