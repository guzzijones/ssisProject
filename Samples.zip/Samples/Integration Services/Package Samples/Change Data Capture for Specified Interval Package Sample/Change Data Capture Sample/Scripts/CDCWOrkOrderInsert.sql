/*=====================================================================
  This file is part of a Microsoft SQL Server Shared Source Application.
  Copyright (C) Microsoft Corporation.  All rights reserved.
 
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
======================================================= */
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20020718', 112) and ModifiedDate < CONVERT(datetime,'20021018', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20021018', 112) and ModifiedDate < CONVERT(datetime,'20021218', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20021218', 112) and ModifiedDate < CONVERT(datetime,'20030218', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20030218', 112) and ModifiedDate < CONVERT(datetime,'20030518', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20030518', 112) and ModifiedDate < CONVERT(datetime,'20030818', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20030818', 112) and ModifiedDate < CONVERT(datetime,'20031018', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20031018', 112) and ModifiedDate < CONVERT(datetime,'20031218', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20031218', 112) and ModifiedDate < CONVERT(datetime,'20040318', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20040318', 112) and ModifiedDate < CONVERT(datetime,'20040518', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20040518', 112) and ModifiedDate < CONVERT(datetime,'20040718', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.WorkOrder
select WorkOrderID, ProductID, OrderQty, ScrappedQty, StartDate, EndDate, DueDate, ScrapReasonID, getdate()
from Production.WorkOrder
where  ModifiedDate >= CONVERT(datetime,'20040718', 112) and ModifiedDate < CONVERT(datetime,'20040918', 112)
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
