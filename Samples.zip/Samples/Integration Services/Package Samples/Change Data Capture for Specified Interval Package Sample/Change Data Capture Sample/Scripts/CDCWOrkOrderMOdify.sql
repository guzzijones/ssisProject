/*=====================================================================
  This file is part of a Microsoft SQL Server Shared Source Application.
  Copyright (C) Microsoft Corporation.  All rights reserved.
 
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
======================================================= */
declare @Iteration int, @Cnt int, @Limit int, @WorkOrderID int, @OrderQty int, @Val float

set @Iteration = 0
set @Val = Rand(100)

While (@Iteration < 10)
begin
	set @Iteration = @Iteration + 1

	select @Cnt = 0, @Limit = 100

	while (@Cnt < @Limit)
	begin
		set @Cnt = @Cnt + 1

		set @Val = Rand()

		select @WorkOrderID = @Val * 16258

		if exists 
		(
			select WorkOrderID from CDCSample.WorkOrder
			where WorkOrderID = @WorkOrderID
		)
		begin
			select @OrderQty = OrderQty
			from CDCSample.WorkOrder
			where WorkOrderID = @WorkOrderID

			set @Val = Rand()
			set @OrderQty = @Val * @OrderQty

			update CDCSample.WorkOrder
			set OrderQty = @OrderQty, ModifiedDate = getdate()
			where WorkOrderID = @WorkOrderID
		end
	end

	waitfor delay '00:00:10'
end
go
