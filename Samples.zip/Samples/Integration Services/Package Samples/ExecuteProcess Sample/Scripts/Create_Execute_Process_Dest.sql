/****************************************************************************
  This file is part of the Microsoft SQL Server Code Samples.
  Copyright (C) Microsoft Corporation.  All rights reserved.

  This source code is intended only as a supplement to Microsoft
  Development Tools and/or on-line documentation.  See these other
  materials for detailed information regarding Microsoft code samples.

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
*****************************************************************************/

/* Check to see if the table Execute_Process_Dest exists. If not, create it.  */

IF OBJECT_ID('dbo.CreateExecuteProcessDest','P') IS NOT NULL
	DROP PROCEDURE CreateExecuteProcessDest
GO
CREATE PROCEDURE CreateExecuteProcessDest
AS
BEGIN
BEGIN TRY
IF NOT EXISTS
(SELECT * FROM [AdventureWorks].dbo.sysobjects where xtype='U' and name = 'Execute_Process_Dest')

CREATE TABLE [AdventureWorks].dbo.Execute_Process_Dest
(
	[Addr1] nvarchar(255) NULL,
	[City] nvarchar(255) NULL,
	[CountryRegion] nvarchar(255) NULL,
	[Customer_id] Int NULL,
	[Fname] text NULL,
	[IncomeBracket] text NULL,
	[Lname] text NULL,
	[Marital] nvarchar(255) NULL,
	[MI] nvarchar(255) NULL,
	[Region] nvarchar (255) NULL,
	[Gender] nvarchar(255) NULL,
	[State] text NULL,
	[Zip] nvarchar (255) NULL
)
ELSE
TRUNCATE TABLE [AdventureWorks].dbo.Execute_Process_Dest
	RETURN 0;
END TRY
BEGIN CATCH
	RETURN 1;
END CATCH
END
GO		



