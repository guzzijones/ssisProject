'=====================================================================  	
'  File:		Program.vb
'
'  Summary:	Entry point for the console application.
'				
'  Date:		6/25/2004
'
'---------------------------------------------------------------------
'   This file is part of the Microsoft SQL Server Code Samples.
'   Copyright (C) Microsoft Corporation.  All rights reserved.
'
'	This source code is intended only as a supplement to Microsoft
'	Development Tools and/or on-line documentation.  See these other
'	materials for detailed information regarding Microsoft code samples.
'
'	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
'   ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
'   THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
'	PARTICULAR PURPOSE.
'=====================================================================  	

Imports System
Imports System.Collections.Generic
Imports System.Text
Imports Microsoft.SqlServer.Dts.Runtime

Namespace Microsoft.Samples.SqlServer.SSIS
    Class Program
        <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals")> Shared Sub Main(ByVal args() As String)
            Dim sortColumn As String = String.Empty

            If args.Length > 0 Then
                sortColumn = args(0)
            End If

            Dim sample As OleDBToFlatFile = New OleDBToFlatFile(sortColumn)

            Console.WriteLine("Press Enter to exit.")
            Console.ReadLine()
        End Sub
    End Class
End Namespace
