namespace EmailLogProviderCS
{
    using System;
    using System.IO;

    class TextLogWriterCS
    {
        #region Variables and Constants

        // Constants.
        private const string MESSAGE_FORMAT = "text";

        // Variables.
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
        private Microsoft.SqlServer.Dts.Runtime.Connections _connections;
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
        private Microsoft.SqlServer.Dts.Runtime.IDTSInfoEvents _events;
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
        private string _subComponent;
        private StreamWriter _messageStreamWriter;

        // Status flags.
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
        private bool _fireEventsAgain;

        #endregion

        #region Initialize

        internal TextLogWriterCS()
        {
            // Not implemented
        }

        internal void InitializeLogWriter(Microsoft.SqlServer.Dts.Runtime.Connections connections, Microsoft.SqlServer.Dts.Runtime.IDTSInfoEvents events, string subComponent, bool fireEventsAgain)
        {
            // Cache object references for later use.
            this._connections = connections;
            this._events = events;

            this._subComponent = subComponent;
            this._fireEventsAgain = fireEventsAgain;
        }

        #endregion

        #region OpenLog and CloseLog

        internal void OpenLogText(StreamWriter messageStreamWriter)
        {
            this._messageStreamWriter = messageStreamWriter;

            this._messageStreamWriter.WriteLine("SSIS Package Log - " + DateTime.Now.ToString());
            this._messageStreamWriter.WriteLine();

            // Write the header row. Disregard dataCode and dataBytes.
            this._messageStreamWriter.WriteLine("Log Entry Name, Computer Name, Operator Name, " +
              "Source Name, Source ID, Execution ID, Message Text, " +
              "Start Time, End Time");
            this._messageStreamWriter.WriteLine();
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        internal void CloseLogText()
        {
            // No action required for plain text format.
        }

        #endregion

        #region Write individual log entries

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "dataCode"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "dataBytes")]
        internal void LogText(string logEntryName, string computerName, string operatorName, string sourceName, string sourceID, string executionID, string messageText, DateTime startTime, DateTime endTime, int dataCode, byte[] dataBytes)
        {
            this._messageStreamWriter.WriteLine(logEntryName + ", " + computerName + ", " + operatorName + ", " + sourceName + ", " + sourceID + ", " + executionID + ", " + messageText + ", " + startTime.ToString() + ", " + endTime.ToString());
        }

        #endregion
    }
}
