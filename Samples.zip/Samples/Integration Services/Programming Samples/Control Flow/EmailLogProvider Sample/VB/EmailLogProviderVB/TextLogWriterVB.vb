Imports System.IO

Public Class TextLogWriterVB

#Region " Variables and Constants "

    ' Constants.
    Private Const MESSAGE_FORMAT As String = "text"

    ' Variables.
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")> _
    Private _connections As Microsoft.SqlServer.Dts.Runtime.Connections
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")> _
    Private _events As Microsoft.SqlServer.Dts.Runtime.IDTSInfoEvents
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")> _
    Private _subComponent As String
    Private _messageStreamWriter As StreamWriter

    ' Status flags.
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")> _
    Private _fireEventsAgain As Boolean

#End Region

#Region " Initialize "

    Friend Sub New()
        '
    End Sub

    Friend Sub InitializeLogWriter(ByVal connections As Microsoft.SqlServer.Dts.Runtime.Connections, ByVal events As Microsoft.SqlServer.Dts.Runtime.IDTSInfoEvents, ByVal subComponent As String, ByVal fireEventsAgain As Boolean)

        ' Cache object references for later use.
        _connections = connections
        _events = events

        _subComponent = subComponent
        _fireEventsAgain = fireEventsAgain

    End Sub

#End Region

#Region " OpenLog and CloseLog "

    Friend Sub OpenLogText(ByVal messageStreamWriter As StreamWriter)

        _messageStreamWriter = messageStreamWriter

        With _messageStreamWriter

            ' Write a title.
            .WriteLine("SSIS Package Log - " _
                & DateTime.Now.ToString(System.Globalization.CultureInfo.InvariantCulture))
            .WriteLine()

            'Write the header row. Disregard dataCode and dataBytes.
            .WriteLine("Log Entry Name, Computer Name, Operator Name, " & _
              "Source Name, Source ID, Execution ID, Message Text, " & _
              "Start Time, End Time")
            .WriteLine()

        End With

    End Sub

    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")> _
    Friend Sub CloseLogText()

        ' No action required for plain text format.

    End Sub

#End Region

#Region " Write individual log entries "

    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId:="dataCode")> _
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId:="dataBytes")> _
    Friend Sub LogText(ByVal logEntryName As String, ByVal computerName As String, _
      ByVal operatorName As String, ByVal sourceName As String, _
      ByVal sourceID As String, ByVal executionID As String, _
      ByVal messageText As String, ByVal startTime As Date, ByVal endTime As Date, _
      ByVal dataCode As Integer, ByVal dataBytes() As Byte)

        _messageStreamWriter.WriteLine( _
          logEntryName & ", " & _
          computerName & ", " & _
          operatorName & ", " & _
          sourceName & ", " & _
          sourceID & ", " & _
          executionID & ", " & _
          messageText & ", " & _
          startTime.ToString(System.Globalization.CultureInfo.InvariantCulture) & ", " & _
          endTime.ToString(System.Globalization.CultureInfo.InvariantCulture))

    End Sub

#End Region

End Class
