namespace Excel2ConnMgrUICS
{
    partial class Excel2ConnMgrUIFormCS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Excel2ConnMgrUIFormCS));
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.chkIMEX = new System.Windows.Forms.CheckBox();
            this.chkHDR = new System.Windows.Forms.CheckBox();
            this.ofdBrowse = new System.Windows.Forms.OpenFileDialog();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.lblExcelFile = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            resources.ApplyResources(this.btnOK, "btnOK");
            this.btnOK.Name = "btnOK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // chkIMEX
            // 
            resources.ApplyResources(this.chkIMEX, "chkIMEX");
            this.chkIMEX.Name = "chkIMEX";
            this.chkIMEX.UseVisualStyleBackColor = true;
            // 
            // chkHDR
            // 
            resources.ApplyResources(this.chkHDR, "chkHDR");
            this.chkHDR.Checked = true;
            this.chkHDR.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkHDR.Name = "chkHDR";
            this.chkHDR.UseVisualStyleBackColor = true;
            // 
            // btnBrowse
            // 
            resources.ApplyResources(this.btnBrowse, "btnBrowse");
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // lblExcelFile
            // 
            this.lblExcelFile.BackColor = System.Drawing.SystemColors.Window;
            this.lblExcelFile.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.lblExcelFile, "lblExcelFile");
            this.lblExcelFile.Name = "lblExcelFile";
            // 
            // Label1
            // 
            resources.ApplyResources(this.Label1, "Label1");
            this.Label1.Name = "Label1";
            // 
            // Excel2ConnMgrUIFormCS
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.chkIMEX);
            this.Controls.Add(this.chkHDR);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.lblExcelFile);
            this.Controls.Add(this.Label1);
            this.Name = "Excel2ConnMgrUIFormCS";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnCancel;
        internal System.Windows.Forms.Button btnOK;
        internal System.Windows.Forms.CheckBox chkIMEX;
        internal System.Windows.Forms.CheckBox chkHDR;
        internal System.Windows.Forms.OpenFileDialog ofdBrowse;
        internal System.Windows.Forms.Button btnBrowse;
        internal System.Windows.Forms.Label lblExcelFile;
        internal System.Windows.Forms.Label Label1;

    }
}