using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Design;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Runtime.Wrapper;
using Microsoft.SqlServer.Dts.Runtime.Design;
using System.Data.OleDb;

namespace Excel2ConnMgrUICS
{
    public partial class Excel2ConnMgrUIFormCS : Form
    {
        public Excel2ConnMgrUIFormCS()
        {
            InitializeComponent();
        }
        #region  Variables & constants

        private const string CONNECTIONNAME_BASE = "Excel2ConnectionManagerCS";

        private ConnectionManager _connectionManager;
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
        private IServiceProvider _serviceProvider;
        private string _connectionName;
        private string _excelFile;

        #endregion

        #region  Properties

        public string ConnectionName
        {
            get
            {
                return _connectionName;
            }
        }

        #endregion

        #region  Form & control event handlers

        private void btnBrowse_Click(System.Object sender, System.EventArgs e)
        {
            {
                ofdBrowse.Title = "Select an existing Excel file";
                ofdBrowse.Filter = "Excel files(*.xls)|*.xls";
                ofdBrowse.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.Personal).ToString();
            }
            if (ofdBrowse.ShowDialog() == DialogResult.OK)
            {
                _excelFile = ofdBrowse.FileName;
                lblExcelFile.Text = _excelFile;
                _connectionName = CONNECTIONNAME_BASE + "." + System.IO.Path.GetFileName(_excelFile);
            }
            EnableControls();
        }

        private void btnOK_Click(System.Object sender, System.EventArgs e)
        {
            ConfigureConnectionManagerFromUI();
            this.DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(System.Object sender, System.EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        #endregion

        #region  Helper functions

        public void Initialize(ConnectionManager connectionManager, IServiceProvider serviceProvider)
        {
            this._connectionManager = connectionManager;
            this._serviceProvider = serviceProvider;
            ConfigureUIFromConnectionManager();
            EnableControls();
        }

        private void EnableControls()
        {
            bool buttonState;
            buttonState = !String.IsNullOrEmpty(lblExcelFile.Text);
            btnOK.Enabled = buttonState;
        }

        private void ConfigureUIFromConnectionManager()
        {

            string tempName;
            string tempExcelFile;
            {
                tempName = _connectionManager.Properties["Name"].GetValue(_connectionManager).ToString();
                if (!String.IsNullOrEmpty(tempName))
                {
                    this._connectionName = tempName;
                }
                else
                {
                    this._connectionName = CONNECTIONNAME_BASE;
                }

                tempExcelFile = _connectionManager.Properties["ExcelFile"].GetValue(_connectionManager).ToString();
                if (!String.IsNullOrEmpty(tempExcelFile))
                {
                    this._excelFile = tempExcelFile;
                    lblExcelFile.Text = this._excelFile;
                }

                chkHDR.Checked = (bool)this._connectionManager.Properties["FirstRowHasColumnNames"].GetValue(this._connectionManager);
                chkIMEX.Checked = (bool)this._connectionManager.Properties["UseImportMode"].GetValue(this._connectionManager);
            }
        }

        private void ConfigureConnectionManagerFromUI()
        {
            {
                this._connectionManager.Properties["Name"].SetValue(this._connectionManager, this._connectionName);
                this._connectionManager.Properties["ExcelFile"].SetValue(this._connectionManager, this._excelFile);
                this._connectionManager.Properties["FirstRowHasColumnNames"].SetValue(this._connectionManager, chkHDR.Checked);
                this._connectionManager.Properties["UseImportMode"].SetValue(this._connectionManager, chkIMEX.Checked);
            }
        }

        #endregion
    }
}