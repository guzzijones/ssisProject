//=====================================================================  	
//
//  File:       IncrementTaskForm.cs
//
//  Summary:    This file contains a Control flow task form.
//
//  Date:       06/09/2005
//
//---------------------------------------------------------------------
//  This file is part of the Microsoft SQL Server Code Samples.
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//
//  This source code is intended only as a supplement to Microsoft
//  Development Tools and/or on-line documentation.  See these other
//  materials for detailed information regarding Microsoft code samples.
//
//  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
//  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
//  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//  PARTICULAR PURPOSE.
//=====================================================================                         

using System;
using System.Globalization;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Runtime;

namespace Microsoft.Samples.SqlServer.Dts
{
    public partial class IncrementTaskForm : Form
    {
        private TaskHost taskHostValue;

        public IncrementTaskForm(TaskHost taskHost)
        {
            if (taskHost == null)
            {
                throw new ArgumentNullException("taskHost");
            }

            InitializeComponent();

            this.taskHostValue = taskHost;

            // Initialize TextBox controls with the values from the Task. These properties are accessed
            // through the task's TaskHost object.
            this.txtInitialValue.Text
                = this.taskHostValue.Properties["InitialValue"].GetValue(taskHost).ToString();
            this.txtLoopCount.Text
                = this.taskHostValue.Properties["LoopCount"].GetValue(taskHost).ToString();
            this.txtIncrementValue.Text
                = this.taskHostValue.Properties["IncrementValue"].GetValue(this.taskHostValue).ToString();
        }

        private void cmdOk_Click(object sender, EventArgs e)
        {
            // Set the properties of the task through the its TaskHost object.
            this.taskHostValue.Properties["LoopCount"].SetValue(this.taskHostValue,
                System.Convert.ToInt32(this.txtLoopCount.Text,
                System.Globalization.CultureInfo.InvariantCulture));
            this.taskHostValue.Properties["InitialValue"].SetValue(this.taskHostValue,
                System.Convert.ToInt32(this.txtInitialValue.Text,
                System.Globalization.CultureInfo.InvariantCulture));
            this.taskHostValue.Properties["IncrementValue"].SetValue(this.taskHostValue,
                System.Convert.ToInt32(this.txtIncrementValue.Text,
                System.Globalization.CultureInfo.InvariantCulture));
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.Windows.Forms.Control.set_Text(System.String)")]
        private void txtInitialValue_Leave(object sender, EventArgs e)
        {
            if (txtInitialValue.Text.Length == 0)
            {
                txtInitialValue.Text = "0";
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.Windows.Forms.Control.set_Text(System.String)")]
        private void txtIncrementValue_Leave(object sender, EventArgs e)
        {
            if (txtIncrementValue.Text.Length == 0)
            {
                txtIncrementValue.Text = "0";
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.Windows.Forms.Control.set_Text(System.String)")]
        private void txtLoopCount_Leave(object sender, EventArgs e)
        {
            if (txtIncrementValue.Text.Length == 0)
            {
                txtIncrementValue.Text = "0";
            }
        }
    }
}