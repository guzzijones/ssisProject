

Partial Class IncrementTaskForm 'The Partial modifier is only required on one class definition per project.
    ''' <summary>
    ''' Required designer variable.
    ''' </summary>
    Private components As System.ComponentModel.IContainer = Nothing
    
    
    ''' <summary>
    ''' Clean up any resources being used.
    ''' </summary>
    ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean) 
        If disposing AndAlso Not (components Is Nothing) Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    
    End Sub
    
    #Region "Windows Form Designer generated code"
    
    
    ''' <summary>
    ''' Required method for Designer support - do not modify
    ''' the contents of this method with the code editor.
    ''' </summary>
    Private Sub InitializeComponent() 
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(IncrementTaskForm))
        Me.label4 = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.cmdOk = New System.Windows.Forms.Button
        Me.label2 = New System.Windows.Forms.Label
        Me.txtLoopCount = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        Me.txtIncrementValue = New System.Windows.Forms.TextBox
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.txtInitialValue = New System.Windows.Forms.TextBox
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'label4
        '
        resources.ApplyResources(Me.label4, "label4")
        Me.label4.Name = "label4"
        '
        'label3
        '
        resources.ApplyResources(Me.label3, "label3")
        Me.label3.Name = "label3"
        '
        'cmdOk
        '
        Me.cmdOk.DialogResult = System.Windows.Forms.DialogResult.OK
        resources.ApplyResources(Me.cmdOk, "cmdOk")
        Me.cmdOk.Name = "cmdOk"
        '
        'label2
        '
        resources.ApplyResources(Me.label2, "label2")
        Me.label2.Name = "label2"
        '
        'txtLoopCount
        '
        resources.ApplyResources(Me.txtLoopCount, "txtLoopCount")
        Me.txtLoopCount.Name = "txtLoopCount"
        '
        'label1
        '
        resources.ApplyResources(Me.label1, "label1")
        Me.label1.Name = "label1"
        '
        'txtIncrementValue
        '
        resources.ApplyResources(Me.txtIncrementValue, "txtIncrementValue")
        Me.txtIncrementValue.Name = "txtIncrementValue"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.label4)
        Me.groupBox1.Controls.Add(Me.label3)
        Me.groupBox1.Controls.Add(Me.label2)
        Me.groupBox1.Controls.Add(Me.txtLoopCount)
        Me.groupBox1.Controls.Add(Me.txtIncrementValue)
        Me.groupBox1.Controls.Add(Me.txtInitialValue)
        resources.ApplyResources(Me.groupBox1, "groupBox1")
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.TabStop = False
        '
        'txtInitialValue
        '
        resources.ApplyResources(Me.txtInitialValue, "txtInitialValue")
        Me.txtInitialValue.Name = "txtInitialValue"
        '
        'IncrementTaskForm
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.cmdOk)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.groupBox1)
        Me.Name = "IncrementTaskForm"
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox1.PerformLayout()
        Me.ResumeLayout(False)
    End Sub
    
    #End Region
    
    Private label4 As System.Windows.Forms.Label
    Private label3 As System.Windows.Forms.Label
    Private WithEvents cmdOk As System.Windows.Forms.Button
    Private label2 As System.Windows.Forms.Label
    Private WithEvents txtLoopCount As System.Windows.Forms.TextBox
    Private label1 As System.Windows.Forms.Label
    Private WithEvents txtIncrementValue As System.Windows.Forms.TextBox
    Private groupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents txtInitialValue As System.Windows.Forms.TextBox
End Class
