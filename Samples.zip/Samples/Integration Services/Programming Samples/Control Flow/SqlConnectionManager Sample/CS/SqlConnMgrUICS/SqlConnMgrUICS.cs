using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SqlServer.Dts.Design;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Runtime.Wrapper;
using Microsoft.SqlServer.Dts.Runtime.Design;
using System.Windows.Forms;

namespace SqlConnMgrUICS
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1724:TypeNamesShouldNotMatchNamespaces"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
    public class SqlConnMgrUICS : IDtsConnectionManagerUI
    {
        private ConnectionManager _connectionManager;
        private IServiceProvider _serviceProvider;

        #region  IDtsConnectionManagerUI interface

        public bool New(System.Windows.Forms.IWin32Window parentWindow, Microsoft.SqlServer.Dts.Runtime.Connections connections, Microsoft.SqlServer.Dts.Runtime.Design.ConnectionManagerUIArgs connectionUIArg)
        {
            IDtsClipboardService clipboardService;

            clipboardService = (IDtsClipboardService)this._serviceProvider.GetService(typeof(IDtsClipboardService));

            // If connection manager has been copied and pasted, take no action.
            if (clipboardService != null)
            {
                if (clipboardService.IsPasteActive)
                {
                    return true;
                }
            }

            return EditSqlConnection(parentWindow);
        }

        public void Initialize(Microsoft.SqlServer.Dts.Runtime.ConnectionManager connectionManager, System.IServiceProvider serviceProvider)
        {
            this._connectionManager = connectionManager;
            this._serviceProvider = serviceProvider;
        }

        public bool Edit(System.Windows.Forms.IWin32Window parentWindow, Microsoft.SqlServer.Dts.Runtime.Connections connections, Microsoft.SqlServer.Dts.Runtime.Design.ConnectionManagerUIArgs connectionUIArg)
        {
            return EditSqlConnection(parentWindow);
        }

        public void Delete(System.Windows.Forms.IWin32Window parentWindow)
        {
            // Not implemented
        }

        #endregion

        #region  Helper functions

        private bool EditSqlConnection(IWin32Window parentWindow)
        {
            SqlConnMgrUIFormCS sqlCMUIForm = new SqlConnMgrUIFormCS();

            sqlCMUIForm.Initialize(_connectionManager, this._serviceProvider);
            if (sqlCMUIForm.ShowDialog(parentWindow) == DialogResult.OK)
            {
                sqlCMUIForm.Dispose();
                return true;
            }
            else
            {
                sqlCMUIForm.Dispose();
                return false;
            }
        }

        #endregion
    }
}
