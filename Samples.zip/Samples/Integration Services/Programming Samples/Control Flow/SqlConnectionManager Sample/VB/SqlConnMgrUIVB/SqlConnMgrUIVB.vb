Imports Microsoft.SqlServer.Dts.Design
Imports Microsoft.SqlServer.Dts.Runtime
Imports Microsoft.SqlServer.Dts.Runtime.Wrapper
Imports Microsoft.SqlServer.Dts.Runtime.Design
Imports System.Windows.Forms

<System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1724:TypeNamesShouldNotMatchNamespaces")> <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")> Public Class SqlConnMgrUIVB
    Implements IDtsConnectionManagerUI

    Private _connectionManager As ConnectionManager
    Private _serviceProvider As IServiceProvider

#Region " IDtsConnectionManagerUI interface "

    Public Function [New](ByVal parentWindow As System.Windows.Forms.IWin32Window, ByVal connections As Microsoft.SqlServer.Dts.Runtime.Connections, ByVal connectionUIArg As Microsoft.SqlServer.Dts.Runtime.Design.ConnectionManagerUIArgs) As Boolean Implements Microsoft.SqlServer.Dts.Runtime.Design.IDtsConnectionManagerUI.New
        Dim clipboardService As IDtsClipboardService

        clipboardService = _
          DirectCast(_serviceProvider.GetService(GetType(IDtsClipboardService)), IDtsClipboardService)
        If Not clipboardService Is Nothing Then
            ' If connection manager has been copied and pasted, take no action.
            If clipboardService.IsPasteActive Then
                Return True
            End If
        End If

        Return EditSqlConnection(parentWindow)
    End Function

    Public Sub Initialize(ByVal connectionManager As Microsoft.SqlServer.Dts.Runtime.ConnectionManager, ByVal serviceProvider As System.IServiceProvider) Implements Microsoft.SqlServer.Dts.Runtime.Design.IDtsConnectionManagerUI.Initialize
        _connectionManager = connectionManager
        _serviceProvider = serviceProvider
    End Sub

    Public Function Edit(ByVal parentWindow As System.Windows.Forms.IWin32Window, ByVal connections As Microsoft.SqlServer.Dts.Runtime.Connections, ByVal connectionUIArg As Microsoft.SqlServer.Dts.Runtime.Design.ConnectionManagerUIArgs) As Boolean Implements Microsoft.SqlServer.Dts.Runtime.Design.IDtsConnectionManagerUI.Edit
        Return EditSqlConnection(parentWindow)
    End Function

    Public Sub Delete(ByVal parentWindow As System.Windows.Forms.IWin32Window) Implements Microsoft.SqlServer.Dts.Runtime.Design.IDtsConnectionManagerUI.Delete
        ' Not implemented
    End Sub

#End Region

#Region " Helper functions "

    Private Function EditSqlConnection(ByVal parentWindow As IWin32Window) As Boolean
        Dim sqlCMUIForm As New SqlConnMgrUIFormVB

        sqlCMUIForm.Initialize(_connectionManager, _serviceProvider)
        If sqlCMUIForm.ShowDialog(parentWindow) = DialogResult.OK Then
            sqlCMUIForm.Dispose()
            Return True
        Else
            sqlCMUIForm.Dispose()
            Return False
        End If
    End Function

#End Region

End Class
