'=====================================================================  	
'
'  File:       ComponentValidation.vb
'
'  Summary:    This file contains a ADO sample.
'
'  Date:       06/09/2005
'
'---------------------------------------------------------------------
'  This file is part of the Microsoft SQL Server Code Samples.
'  Copyright (C) Microsoft Corporation.  All rights reserved.
'
'  This source code is intended only as a supplement to Microsoft
'  Development Tools and/or on-line documentation.  See these other
'  materials for detailed information regarding Microsoft code samples.
'
'  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
'  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
'  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
'  PARTICULAR PURPOSE.
'=====================================================================                         

Imports System
Imports Microsoft.SqlServer.Dts.Pipeline.Wrapper
Imports Microsoft.SqlServer.Dts.Runtime.Wrapper

' <summary>
' Helper class for validating the columns in input and output objects. The functions for input columns verify 
' that the column metadata for the input columns matches that of the output column on the upstream component.
' 
' <summary>

<System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1053:StaticHolderTypesShouldNotHaveConstructors")> _
Public Class ComponentValidation

    Public Sub New()
    End Sub

    <CLSCompliant(False)> _
    Public Shared Function DoesInputColumnMatchVirtualInputColumns(ByVal input As IDTSInput100) As Boolean
        If input Is Nothing Then
            Throw New ArgumentNullException("input")
        End If

        Dim vInput As IDTSVirtualInput100 = input.GetVirtualInput
        Dim Cancel As Boolean = False
        Dim areAllColumnsValid As Boolean = True
        For Each column As IDTSInputColumn100 In input.InputColumnCollection
            Dim vColumn As IDTSVirtualInputColumn100 = vInput.VirtualInputColumnCollection.GetVirtualInputColumnByLineageID(column.LineageID)
            If Not ComponentValidation.DoesColumnMetaDataMatch(column, vColumn) Then
                areAllColumnsValid = False
                input.Component.FireError(0, input.Component.Name, "The input column metadata for column" + column.IdentificationString + " does not match its upstream column.", "", 0, Cancel)
            End If
        Next
        Return areAllColumnsValid
    End Function

    Private Shared Function DoesColumnMetaDataMatch(ByVal column As IDTSInputColumn100, ByVal vColumn As IDTSVirtualInputColumn100) As Boolean
        If vColumn.DataType = column.DataType AndAlso vColumn.Precision = column.Precision AndAlso vColumn.Length = column.Length AndAlso vColumn.Scale = column.Scale Then
            Return True
        End If

        Return False
    End Function

    <CLSCompliant(False)> _
    Public Shared Sub FixInvalidInputColumnMetaData(ByVal input As IDTSInput100)
        If input Is Nothing Then
            Throw New ArgumentNullException("input")
        End If

        Dim vInput As IDTSVirtualInput100 = input.GetVirtualInput
        For Each inputColumn As IDTSInputColumn100 In input.InputColumnCollection
            Dim vColumn As IDTSVirtualInputColumn100 = vInput.VirtualInputColumnCollection.GetVirtualInputColumnByLineageID(inputColumn.LineageID)
            If Not DoesColumnMetaDataMatch(inputColumn, vColumn) Then
                vInput.SetUsageType(vColumn.LineageID, inputColumn.UsageType)
            End If
        Next
    End Sub

    <CLSCompliant(False)> _
    Public Shared Function DoesOutputColumnMetaDataMatchExternalColumnMetaData(ByVal output As IDTSOutput100) As Boolean
        If output Is Nothing Then
            Throw New ArgumentNullException("output")
        End If

        Dim areAllOutputColumnsValid As Boolean = True
        If output.ExternalMetadataColumnCollection.Count = 0 Then
            Return False
        End If

        For Each column As IDTSOutputColumn100 In output.OutputColumnCollection
            Dim Cancel As Boolean = False
            Dim exColumn As IDTSExternalMetadataColumn100 = output.ExternalMetadataColumnCollection.GetObjectByID(column.ExternalMetadataColumnID)
            If Not DoesColumnMetaDataMatch(column, exColumn) Then
                output.Component.FireError(0, output.Component.Name, "The output column " + column.IdentificationString + " does not match the external metadata.", "", 0, Cancel)
                areAllOutputColumnsValid = False
            End If
        Next
        Return areAllOutputColumnsValid
    End Function

    <CLSCompliant(False)> _
    Public Shared Function DoesExternalMetaDataMatchOutputMetaData(ByVal output As IDTSOutput100) As Boolean
        If output Is Nothing Then
            Throw New ArgumentNullException("output")
        End If

        Dim externalMetaData As IDTSExternalMetadataColumnCollection100 = output.ExternalMetadataColumnCollection
        For Each column As IDTSOutputColumn100 In output.OutputColumnCollection
            If Not DoesColumnMetaDataMatch(column, externalMetaData.GetObjectByID(column.ExternalMetadataColumnID)) Then
                Return False
            End If
        Next
        Return True
    End Function

    <CLSCompliant(False)> _
    Public Shared Sub FixExternalMetaDataColumns(ByVal output As IDTSOutput100)
        If output Is Nothing Then
            Throw New ArgumentNullException("output")
        End If

        Dim externalMetaData As IDTSExternalMetadataColumnCollection100 = output.ExternalMetadataColumnCollection
        externalMetaData.RemoveAll()
        For Each column As IDTSOutputColumn100 In output.OutputColumnCollection
            Dim exColumn As IDTSExternalMetadataColumn100 = externalMetaData.New
            exColumn.Name = column.Name
            exColumn.DataType = column.DataType
            exColumn.Precision = column.Precision
            exColumn.Scale = column.Scale
            exColumn.Length = column.Length
            column.ExternalMetadataColumnID = exColumn.ID
        Next
    End Sub

    Private Shared Function DoesColumnMetaDataMatch(ByVal column As IDTSOutputColumn100, ByVal exCol As IDTSExternalMetadataColumn100) As Boolean
        If column.DataType = exCol.DataType AndAlso column.Precision = exCol.Precision AndAlso column.Length = exCol.Length AndAlso column.Scale = exCol.Scale Then
            Return True
        End If

        Return False
    End Function

    <CLSCompliant(False)> _
    Public Shared Sub FixOutputColumnMetaData(ByVal output As IDTSOutput100)
        If output Is Nothing Then
            Throw New ArgumentNullException("output")
        End If

        If output.ExternalMetadataColumnCollection.Count = 0 Then
            Return
        End If

        For Each column As IDTSOutputColumn100 In output.OutputColumnCollection
            Dim exColumn As IDTSExternalMetadataColumn100 = output.ExternalMetadataColumnCollection.GetObjectByID(column.ExternalMetadataColumnID)
            If Not DoesColumnMetaDataMatch(column, exColumn) Then
                column.SetDataTypeProperties(exColumn.DataType, exColumn.Length, exColumn.Precision, exColumn.Scale, exColumn.CodePage)
            End If
        Next
    End Sub
End Class