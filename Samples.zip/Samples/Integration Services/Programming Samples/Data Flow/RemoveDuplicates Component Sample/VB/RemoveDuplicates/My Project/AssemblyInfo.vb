
Imports System
Imports System.Security.Permissions
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("RemoveDuplicatesVB")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft Corporation")> 
<Assembly: AssemblyProduct("RemoveDuplicates")> 
<Assembly: AssemblyCopyright("Copyright � Microsoft Corporation 2005")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("7eca246f-8b0b-4994-b091-08ddad75073f")> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
<Assembly: PermissionSet(SecurityAction.RequestMinimum)> 
<Assembly: CLSCompliant(True)> 
