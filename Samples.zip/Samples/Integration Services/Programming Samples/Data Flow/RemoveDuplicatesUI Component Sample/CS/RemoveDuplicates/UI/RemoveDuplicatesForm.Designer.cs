namespace Microsoft.Samples.SqlServer.Dts
{
    partial class RemoveDuplicatesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RemoveDuplicatesForm));
            this.labelDescription = new System.Windows.Forms.Label();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.dataGridViewAvailableColumns = new System.Windows.Forms.DataGridView();
            this.gridColumnCheckbox = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.gridColumnAvailableColumns = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewSelectedColumns = new System.Windows.Forms.DataGridView();
            this.gridColumnInputColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridcolumnDistinctOutputColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridcolumnDuplicateOutputColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonOK = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAvailableColumns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSelectedColumns)).BeginInit();
            this.SuspendLayout();
            // 
            // labelDescription
            // 
            resources.ApplyResources(this.labelDescription, "labelDescription");
            this.labelDescription.Name = "labelDescription";
            // 
            // splitContainer
            // 
            resources.ApplyResources(this.splitContainer, "splitContainer");
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.dataGridViewAvailableColumns);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.dataGridViewSelectedColumns);
            // 
            // dataGridViewAvailableColumns
            // 
            this.dataGridViewAvailableColumns.AllowUserToAddRows = false;
            this.dataGridViewAvailableColumns.AllowUserToDeleteRows = false;
            this.dataGridViewAvailableColumns.AllowUserToResizeRows = false;
            resources.ApplyResources(this.dataGridViewAvailableColumns, "dataGridViewAvailableColumns");
            this.dataGridViewAvailableColumns.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAvailableColumns.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gridColumnCheckbox,
            this.gridColumnAvailableColumns});
            this.dataGridViewAvailableColumns.Name = "dataGridViewAvailableColumns";
            this.dataGridViewAvailableColumns.RowHeadersVisible = false;
            this.dataGridViewAvailableColumns.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAvailableColumns.CurrentCellDirtyStateChanged += new System.EventHandler(this.dataGridViewAvailableColumns_CurrentCellDirtyStateChanged);
            this.dataGridViewAvailableColumns.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAvailableColumns_CellValueChanged);
            // 
            // gridColumnCheckbox
            // 
            this.gridColumnCheckbox.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            resources.ApplyResources(this.gridColumnCheckbox, "gridColumnCheckbox");
            this.gridColumnCheckbox.Name = "gridColumnCheckbox";
            // 
            // gridColumnAvailableColumns
            // 
            this.gridColumnAvailableColumns.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            resources.ApplyResources(this.gridColumnAvailableColumns, "gridColumnAvailableColumns");
            this.gridColumnAvailableColumns.Name = "gridColumnAvailableColumns";
            this.gridColumnAvailableColumns.ReadOnly = true;
            // 
            // dataGridViewSelectedColumns
            // 
            this.dataGridViewSelectedColumns.AllowUserToAddRows = false;
            this.dataGridViewSelectedColumns.AllowUserToDeleteRows = false;
            this.dataGridViewSelectedColumns.AllowUserToResizeRows = false;
            this.dataGridViewSelectedColumns.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewSelectedColumns.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSelectedColumns.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gridColumnInputColumn,
            this.gridcolumnDistinctOutputColumn,
            this.gridcolumnDuplicateOutputColumn});
            resources.ApplyResources(this.dataGridViewSelectedColumns, "dataGridViewSelectedColumns");
            this.dataGridViewSelectedColumns.Name = "dataGridViewSelectedColumns";
            this.dataGridViewSelectedColumns.RowHeadersVisible = false;
            this.dataGridViewSelectedColumns.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSelectedColumns.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSelectedColumns_CellEndEdit);
            // 
            // gridColumnInputColumn
            // 
            this.gridColumnInputColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            resources.ApplyResources(this.gridColumnInputColumn, "gridColumnInputColumn");
            this.gridColumnInputColumn.Name = "gridColumnInputColumn";
            this.gridColumnInputColumn.ReadOnly = true;
            // 
            // gridcolumnDistinctOutputColumn
            // 
            this.gridcolumnDistinctOutputColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            resources.ApplyResources(this.gridcolumnDistinctOutputColumn, "gridcolumnDistinctOutputColumn");
            this.gridcolumnDistinctOutputColumn.Name = "gridcolumnDistinctOutputColumn";
            // 
            // gridcolumnDuplicateOutputColumn
            // 
            this.gridcolumnDuplicateOutputColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            resources.ApplyResources(this.gridcolumnDuplicateOutputColumn, "gridcolumnDuplicateOutputColumn");
            this.gridcolumnDuplicateOutputColumn.Name = "gridcolumnDuplicateOutputColumn";
            // 
            // buttonOK
            // 
            resources.ApplyResources(this.buttonOK, "buttonOK");
            this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.UseVisualStyleBackColor = true;
            // 
            // buttonCancel
            // 
            resources.ApplyResources(this.buttonCancel, "buttonCancel");
            this.buttonCancel.CausesValidation = false;
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // RemoveDuplicatesForm
            // 
            this.AcceptButton = this.buttonOK;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonCancel;
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.labelDescription);
            this.Name = "RemoveDuplicatesForm";
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAvailableColumns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSelectedColumns)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelDescription;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.DataGridView dataGridViewSelectedColumns;
        private System.Windows.Forms.DataGridView dataGridViewAvailableColumns;
        private System.Windows.Forms.DataGridViewCheckBoxColumn gridColumnCheckbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridColumnAvailableColumns;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridColumnInputColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridcolumnDistinctOutputColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridcolumnDuplicateOutputColumn;
    }
}